package com.example.gamesuit

class StringContainer {
    val rock: String = "rock"
    val scissors: String = "scissors"
    val paper: String = "paper"
}
