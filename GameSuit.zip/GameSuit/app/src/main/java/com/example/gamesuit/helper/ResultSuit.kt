package com.example.gamesuit.helper

class ResultSuit(val status: String) {
    companion object {
        const val WIN: String = ""
        const val LOSE: String = ""
        const val DRAW: String = ""
    }
}