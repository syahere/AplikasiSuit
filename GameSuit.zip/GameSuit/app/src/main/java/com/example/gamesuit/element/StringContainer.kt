package com.example.gamesuit.element

object StringContainer {
    const val rock: String = "rock"
    const val scissors: String = "scissors"
    const val paper: String = "paper"
}